CREATE TRIGGER after_object_delete
            AFTER DELETE ON object
            FOR EACH ROW
        BEGIN
            DELETE FROM relationship
            WHERE id IN (
                SELECT id FROM relationship
                WHERE object_id = OLD.id
            );
        END;

