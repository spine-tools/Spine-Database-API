CREATE TRIGGER after_object_class_delete
            AFTER DELETE ON object_class
            FOR EACH ROW
        BEGIN
            DELETE FROM relationship_class
            WHERE id IN (
                SELECT id FROM relationship_class
                WHERE object_class_id = OLD.id
            );
        END;

